# Post-processing Stack v2

This branch is under active development and holds the current version of the post-processing stack. 

Instructions
------------

Documentation is available [on the wiki](https://github.com/Unity-Technologies/PostProcessing/wiki).

The current version requires Unity 5.6.1+. Some effects and features are only available on newer versions of Unity.

License
-------

Unity Companion License (see [LICENSE](LICENSE.md))
